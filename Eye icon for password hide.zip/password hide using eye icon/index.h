<html>

<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>

/* Bordered form */
form {
    border: 3px solid #f1f1f1;
}

<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>

</style>

<head>

<center><h1>Mushroom Device</h1></center><br><br>

</head>

<body>

<form method="get" action="/form">

<!--<form method ="get">-->
  
  <div class="container">
    <label><h2>SSID</h2></label>
    <input type="text" placeholder="Enter your Home ssid" name="ssid" required>

    <label><h2>Password</h2></label>
    <input type="password" placeholder="Enter Password" name="password" id="myInput" required>
    <br>
    <!-- An element to toggle between password visibility -->
    <input type="checkbox" onclick="myFunction()">Show Password
    <br><br>
    <button type="submit"><b>Save</b></button>
    
  </div>
</form>
</body>

<script>

function myFunction() {
    var x = document.getElementById("myInput");
    if (x.type === "password") {
        x.type = "text";
    } else {
        x.type = "password";
    }
}
</script>
</html>


