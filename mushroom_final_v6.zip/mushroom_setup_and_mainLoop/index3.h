const char MAIN_page3[] PROGMEM = R"=====(

<html>

<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel= "stylesheet" href="bootstrap-3.3.7-dist/css/bootstrap.min.css"/>
<script src="bootstrap-3.3.7-dist/js/bootstrap.min.js" ></script>
<script src="jquery.min.js"></script>    


<style>
/* Bordered form */
form {
    border: 3px solid #f1f1f1;
}

.form-group {
  position: relative
}

/* Full-width inputs */
input[type=text], input[type=password] {
    width: 100%;
    padding: 12px 20px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    box-sizing: border-box;
}

/* Set a style for all buttons */
button {
    background-color: #4CAF50;
    color: white;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    cursor: pointer;
    width: 100%;
    font-size : 20px; 
}

/* Add padding to containers */
.container {
    padding: 16px;
}

.form-group .glyphicon {
  right: 65px;
  position:absolute;
  top:88px
}

</style>

<head>

<center><h1>Mushroom Device</h1></center><br><br>

</head>

<body>

<form method="get"  action="/form">

<!--<form method ="get">-->
  
   <div class="form-group">
    
	<label><h2>SSID</h2></label>
    <input type="text" placeholder="Enter your Home ssid" name="ssid" required>
   
   </div>
   
   <div class="form-group">
   
   <label><h2>Password</h2></label>
   <input type="password" placeholder="Enter Password" name="password" id="password" required>
   <span class="glyphicon glyphicon-eye-open"></span>
    
   
   </div>
    
    <button type="submit"><b>Save</b></button>
    
  
</form>
</body>

<script>

$(".glyphicon-eye-open").on("click", function() {
$(this).toggleClass("glyphicon-eye-close");
var type = $("#password").attr("type");
if (type == "text"){ 
  $("#password").prop('type','password');}
else{ 
  $("#password").prop('type','text'); }
});

</script>

</html>

)=====";