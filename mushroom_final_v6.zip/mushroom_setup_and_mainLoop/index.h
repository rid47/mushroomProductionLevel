const char MAIN_page[] PROGMEM = R"=====(

<html>

<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>

/* Bordered form */
form {
    border: 3px solid #f1f1f1;
}

/* Full-width inputs */
input[type=text], input[type=password] {
    width: 100%;
    padding: 12px 20px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    box-sizing: border-box;
}

/* Set a style for all buttons */
button {
    background-color: #4CAF50;
    color: white;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    cursor: pointer;
    width: 100%;
    font-size : 20px; 
}

/* Add padding to containers */
.container {
    padding: 16px;
}

</style>

<head>

<center><h1>Mushroom Device</h1></center><br><br>

</head>

<body>

<form method="get" action="/form">

<!--<form method ="get">-->
  
  <div class="container">
    <label><h2>SSID</h2></label>
    <input type="text" placeholder="Enter your Home ssid" name="ssid" required>

    <label><h2>Password</h2></label>
    <input type="password" placeholder="Enter Password" name="password" id="myInput" required>
    <br>
    <!-- An element to toggle between password visibility -->
    <input type="checkbox" onclick="myFunction()">Show Password
    <br><br>
    <button type="submit"><b>Save</b></button>
    
  </div>
</form>
</body>

<script>

function myFunction() {
    var x = document.getElementById("myInput");
    if (x.type === "password") {
        x.type = "text";
    } else {
        x.type = "password";
    }
}
</script>
</html>

 )=====";
