const char MAIN_page2[] PROGMEM = R"=====(


<html>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<head>

<center><h1>Mushroom Device</h1></center><br><br>

</head>

<body>

<center> <h2>WiFi Credentials saved</h2></center>
<br><br>
<center>Check WiFi indicator of your device;<br>
if it is still off try again...</br>
<center>
</body>
</html>

 )=====";
